"""functools, especially backported from Python 3."""

from __future__ import annotations

import builtins
import cProfile
import pstats
import signal
import sys
import tempfile
from functools import cached_property, partial, update_wrapper, wraps
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import Callable
    from typing import Any, Union


def _mangle(name: str, cls: type) -> str:
    """Apply Python's private name mangling of ``name`` within class ``cls``."""
    if name.startswith("__") and not name.endswith("__"):
        return f"_{cls.__name__.lstrip('_')}{name}"
    return name


class lazy_property(cached_property):
    """Descriptor that turns a method into a lazily evaluated attribute.

    The wrapped function is called once on first access; the returned value
    is cached on the instance's ``__dict__`` for subsequent lookups.

    Built on ``functools.cached_property``, with these differences:

    - The value is cached under the (mangled) name of the wrapped function,
      so a descriptor may be bound to several names, or set on a class after
      creation.
    - Objects without a ``__dict__`` (e.g. ``__slots__`` classes) raise
      ``AttributeError`` rather than ``TypeError``.
    - ``__name__``, ``__qualname__``, ``__module__`` and ``__doc__`` are
      copied from the wrapped function.
    - Cached values can be cleared with :meth:`invalidate`.
    """

    def __init__(self, func: Callable) -> None:
        """Initialize the descriptor.

        Args:
            func: Function to decorate.

        """
        super().__init__(func)
        update_wrapper(self, func)  # type: ignore[arg-type]

    def __set_name__(self, owner: type, name: str) -> None:
        if self.attrname is None:
            self.attrname = _mangle(self.func.__name__, owner)

    def __get__(self, inst: Any, owner: type | None = None) -> Any:
        if inst is None:
            return self

        try:
            inst.__dict__  # noqa: B018
        except AttributeError as exc:
            raise AttributeError(
                f"'{type(inst).__name__}' object has no attribute '__dict__'"
            ) from exc

        if self.attrname is None:
            self.attrname = _mangle(self.func.__name__, type(inst))
        return super().__get__(inst, owner)

    @classmethod
    def invalidate(cls, inst: object, name: str) -> None:
        """Invalidate a lazy attribute.

        This obviously violates the lazy contract. A subclass of lazy
        may however have a contract where invalidation is appropriate.
        """
        inst_cls = inst.__class__

        if not hasattr(inst, "__dict__"):
            raise AttributeError(
                f"'{inst_cls.__name__}' object has no attribute '__dict__'"
            )

        name = _mangle(name, inst_cls)

        if not isinstance(getattr(inst_cls, name), cls):
            raise AttributeError(
                f"'{inst_cls.__name__}.{name}' is not a {cls.__name__} attribute"
            )

        inst.__dict__.pop(name, None)


def return_if_raise(
    exception_tuple: list | tuple, retval_if_exc: Any, disabled: bool = False
) -> Any:
    """Return ``retval_if_exc`` when the decorated callable raises a listed exception.

    The callable is invoked inside a ``try`` block; any of the exceptions in
    ``exception_tuple`` cause ``retval_if_exc`` to be returned instead (see
    also ``return_node_if_raise``). Setting ``disabled=True`` skips the
    ``try``/``except`` (useful for debugging). Works on functions, methods,
    and properties.

    Examples:
        @return_if_raise(ValueError, None)
        def return_none_if_value_error(self):
            pass

        @return_if_raise((ValueError, KeyError), "hello")
        def another_method(self):
            pass

        @property
        @return_if_raise(AttributeError, None)
        def name(self):
            "Name of the object, None if not set."
            return self._name

    """
    # we need a tuple of exceptions.
    if isinstance(exception_tuple, list):
        exception_tuple = tuple(exception_tuple)
    elif isinstance(exception_tuple, type) and issubclass(
        exception_tuple, BaseException
    ):
        exception_tuple = (exception_tuple,)
    elif not isinstance(exception_tuple, tuple):
        raise TypeError(f"Wrong exception_tuple {type(exception_tuple)}")

    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            if disabled:
                return func(*args, **kwargs)
            try:
                return func(*args, **kwargs)
            except exception_tuple:  # pylint: disable=E0712
                return retval_if_exc

        return wrapper

    return decorator


# One could use None as default value in return_if_raise but this one is
# explicit and  more readable
return_none_if_raise = partial(return_if_raise, retval_if_exc=None)
"""
This decorator returns None if one of the exceptions is raised.

    @return_none_if_raise(ValueError)
    def method(self):
"""


class timeout:
    """Context manager that aborts a block of code after a time limit.

    Works only on Unix-based systems since it relies on ``signal.SIGALRM``.

    Examples:
        >>> try:
        ...     with timeout(3):
        ...         do_stuff()
        ... except TimeoutError:
        ...     do_something_else()

    """

    def __init__(self, seconds: int = 1, error_message: str = "Timeout"):
        """Initialize the timeout context manager.

        Args:
            seconds (int): Allowed time for function in seconds.
            error_message (str): An error message.

        """
        self.seconds = seconds
        self.error_message = error_message

    def handle_timeout(self, signum: int, frame: Any) -> None:
        """Signal handler that raises TimeoutError.

        Args:
            signum: Return signal from call.
            frame: Current stack frame.

        """
        raise TimeoutError(self.error_message)

    def __enter__(self) -> None:
        signal.signal(signal.SIGALRM, self.handle_timeout)
        signal.alarm(self.seconds)

    def __exit__(self, type: Any, value: Any, traceback: Any) -> None:
        signal.alarm(0)


class TimeoutError(builtins.TimeoutError):
    """Exception raised by :class:`timeout` when the time limit is exceeded.

    Subclasses the built-in ``TimeoutError``, so ``except TimeoutError``
    catches it without importing it from monty.
    """

    def __init__(self, message: str):
        """Initialize the exception.

        Args:
            message: Error message.

        """
        super().__init__(message)
        self.message = message


def prof_main(main: Callable) -> Callable:
    """Decorator for profiling main programs.

    Profiling is activated by prepending the command line options
    supported by the original main program with the keyword `prof`.

    Examples:
            $ script.py arg --foo=1

        becomes

            $ script.py prof arg --foo=1

        The decorated main accepts two new arguments:

            prof_file: Name of the output file with profiling data
                If not given, a temporary file is created.
            sortby: Profiling data are sorted according to this value.
                default is "time". See sort_stats.

    """

    @wraps(main)
    def wrapper(*args, **kwargs):
        try:
            do_prof = sys.argv[1] == "prof"
            if do_prof:
                sys.argv.pop(1)
        except Exception:
            do_prof = False

        if not do_prof:
            sys.exit(main())
        else:
            print("Entering profiling mode...")
            prof_file = kwargs.get("prof_file")
            if prof_file is None:
                _, prof_file = tempfile.mkstemp()
                print(f"Profiling data stored in {prof_file}")

            sortby = kwargs.get("sortby", "time")
            cProfile.runctx("main()", globals(), locals(), prof_file)
            s = pstats.Stats(prof_file)
            s.strip_dirs().sort_stats(sortby).print_stats()
            if "retval" not in kwargs:
                sys.exit(0)
            else:
                return kwargs["retval"]

    return wrapper
