"""Path based methods, e.g., which, zpath, etc."""

from __future__ import annotations

import os
from typing import TYPE_CHECKING

from monty.fnmatch import WildCard
from monty.string import list_strings

if TYPE_CHECKING:
    from collections.abc import Callable
    from typing import Literal, Optional, Union

    from monty.shutil import PathLike


def zpath(filename: PathLike) -> str:
    """Return an existing (zipped or unzipped) path for ``filename``.

    Probes for ``filename`` and the common compressed variants. If none
    exist, the input is returned unchanged.

    Args:
        filename: Filename without a zip extension.

    Returns:
        str: Filename with a zip extension if such a file exists, otherwise
        the unzipped name (returned unchanged if no variant is found).

    """
    filename = str(filename)  # ensure we work with strings
    # First entry is empty so we probe the unzipped form below; skip it when
    # stripping suffixes since ``removesuffix("")`` is a no-op.
    exts = ("", ".gz", ".GZ", ".bz2", ".BZ2", ".z", ".Z")
    for ext in exts[1:]:
        filename = filename.removesuffix(ext)

    for ext in exts:
        zfilename = f"{filename}{ext}"
        if os.path.exists(zfilename):
            return zfilename
    return filename


def find_exts(
    top: str,
    exts: str | list[str],
    exclude_dirs: str | None = None,
    include_dirs: str | None = None,
    match_mode: Literal["basename", "abspath"] = "basename",
) -> list[str]:
    """Find all files matching ``exts`` under the directory tree rooted at ``top``.

    Includes ``top`` itself but excludes ``.`` and ``..``.

    Args:
        top (str): Root directory
        exts (str or list of strings): List of extensions.
        exclude_dirs (str): Wildcards used to exclude particular directories.
            Can be concatenated via `|`
        include_dirs (str): Wildcards used to select particular directories.
            `include_dirs` and `exclude_dirs` are mutually exclusive
        match_mode (str): "basename" if  match should be done on the basename.
            "abspath" for absolute path.

    Returns:
        list[str]: Absolute paths of the files.

    Examples:
        # Find all pdf and ps files starting from the current directory.
        find_exts(".", ("pdf", "ps"))

        # Find all pdf files, exclude hidden directories and dirs whose name
        # starts with `_`
        find_exts(".", "pdf", exclude_dirs="_*|.*")

        # Find all ps files, in the directories whose basename starts with
        # output.
        find_exts(".", "ps", include_dirs="output*"))

    """
    # ``str.endswith`` accepts a tuple at the C level, which is several times
    # faster than the equivalent ``any(... for ext in exts)`` comprehension.
    _exts: tuple[str, ...] = tuple(list_strings(exts))

    # Handle file!
    if os.path.isfile(top):
        return [os.path.abspath(top)] if top.endswith(_exts) else []

    # Build shell-style wildcards.
    if exclude_dirs is not None:
        _exclude_dirs: WildCard = WildCard(exclude_dirs)

    if include_dirs is not None:
        _include_dirs: WildCard = WildCard(include_dirs)

    mangle_functions: dict[str, Callable[..., str]] = {
        "basename": os.path.basename,
        "abspath": os.path.abspath,
    }
    mangle: Callable[..., str] = mangle_functions[match_mode]

    # Assume directory
    paths: list[str] = []
    for dirpath, _dirnames, filenames in os.walk(top):
        dirpath = os.path.abspath(dirpath)

        if exclude_dirs and _exclude_dirs.match(mangle(dirpath)):
            continue
        if include_dirs and not _include_dirs.match(mangle(dirpath)):
            continue

        paths.extend(
            os.path.join(dirpath, filename)
            for filename in filenames
            if filename.endswith(_exts)
        )

    return paths
